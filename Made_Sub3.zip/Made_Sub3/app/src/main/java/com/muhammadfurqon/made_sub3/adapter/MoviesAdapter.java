package com.muhammadfurqon.made_sub3.adapter;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.muhammadfurqon.made_sub3.BuildConfig;
import com.muhammadfurqon.made_sub3.R;
import com.muhammadfurqon.made_sub3.activity.MoviesDetailActivity;
import com.muhammadfurqon.made_sub3.model.Movies;
import com.bumptech.glide.Glide;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MoviesAdapter extends RecyclerView.Adapter<MoviesAdapter.MovieViewHolder> {

    private ArrayList<Movies> mData = new ArrayList<>();
    public void setData(ArrayList<Movies> items) {
        mData.clear();
        mData.addAll(items);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public MovieViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int position) {
        View mView = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_cardview_movies, viewGroup, false);
        return new MovieViewHolder(mView);
    }

    @Override
    public void onBindViewHolder(@NonNull MovieViewHolder movieViewHolder, int position) {
        movieViewHolder.bind(mData.get(position));
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    class MovieViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        ImageView imgPhoto;
        TextView tVTitle, tVDateReleased,
                tVVoteAverage, tVVoteCount;

        MovieViewHolder(@NonNull View itemView) {
            super(itemView);
            tVTitle = itemView.findViewById(R.id.tv_item_title);
            tVDateReleased = itemView.findViewById(R.id.tv_item_dateReleased);
            tVVoteAverage = itemView.findViewById(R.id.tv_item_voteAverege);
            tVVoteCount = itemView.findViewById(R.id.tv_item_voteCount);
            imgPhoto = itemView.findViewById(R.id.img_item_photo);


            itemView.setOnClickListener(this);
        }
        void bind(Movies movies) {
            String vote_average = Double.toString(movies.getVote_average());
            String url_image = BuildConfig.IMAGE_DB_URL + movies.getPhoto();


            tVTitle.setText(movies.getTitle());
            tVDateReleased.setText(movies.getRelease_date());
            tVVoteAverage.setText(vote_average);
            tVVoteCount.setText(movies.getVote_count());


            Glide.with(itemView.getContext())
                    .load(url_image)
                    .placeholder(R.color.colorAccent)
                    .dontAnimate()
                    .into(imgPhoto);

        }

        @Override
        public void onClick(View v) {
            int position = getAdapterPosition();
            Movies movie = mData.get(position);
//
            movie.setTitle(movie.getTitle());
            movie.setOverview(movie.getOverview());

            Intent moveWithObjectIntent = new Intent(itemView.getContext(), MoviesDetailActivity.class);
            moveWithObjectIntent.putExtra(MoviesDetailActivity.EXTRA_MOVIE, movie);
            itemView.getContext().startActivity(moveWithObjectIntent);
        }
    }


}
