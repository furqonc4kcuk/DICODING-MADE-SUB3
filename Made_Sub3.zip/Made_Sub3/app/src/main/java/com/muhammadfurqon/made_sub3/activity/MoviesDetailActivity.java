package com.muhammadfurqon.made_sub3.activity;

import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.muhammadfurqon.made_sub3.BuildConfig;
import com.muhammadfurqon.made_sub3.R;
import com.muhammadfurqon.made_sub3.model.Movies;
import com.bumptech.glide.Glide;

public class MoviesDetailActivity extends AppCompatActivity {
    public static final String EXTRA_MOVIE = "extra_movie";

    TextView tvTtl, tvVAvr, tvVCount, tvLanguage, tvOview;

    private ProgressBar progressBar;
    ImageView imagePhoto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movies_detail);

        tvTtl = findViewById(R.id.tv_item_title);
        tvVAvr = findViewById(R.id.tv_item_voteAverege);
        tvVCount = findViewById(R.id.tv_item_voteCount);
        tvOview = findViewById(R.id.tv_item_overview);
        tvLanguage = findViewById(R.id.tv_item_language);
        imagePhoto = findViewById(R.id.img_item_photo);

        progressBar = findViewById(R.id.progressDetailMovie);

        progressBar.setVisibility(View.VISIBLE);
        final Handler handler = new Handler();

        new Thread(new Runnable() {
            public void run() {
                try{
                    Thread.sleep(5000);
                }
                catch (Exception e) { }

                handler.post(new Runnable() {
                    public void run() {
                        Movies movie = getIntent().getParcelableExtra(EXTRA_MOVIE);

                        String vote_average = Double.toString(movie.getVote_average());
                        String url_image = BuildConfig.IMAGE_DB_URL + movie.getPhoto();

                        tvTtl.setText(movie.getTitle());
                        tvVAvr.setText(vote_average);
                        tvVCount.setText(movie.getVote_count());
                        tvOview.setText(movie.getOverview());
                        tvLanguage.setText(movie.getOriginal_language()) ;
                        Glide.with(MoviesDetailActivity.this)
                                .load(url_image)
                                .placeholder(R.color.colorAccent)
                                .dontAnimate()
                                .into(imagePhoto);
                        progressBar.setVisibility(View.INVISIBLE);
                    }
                });
            }
        }).start();
    }

}