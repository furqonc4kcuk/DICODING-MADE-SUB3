package com.muhammadfurqon.made_sub3.activity;

import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.muhammadfurqon.made_sub3.BuildConfig;
import com.muhammadfurqon.made_sub3.R;
import com.muhammadfurqon.made_sub3.model.TVShow;
import com.bumptech.glide.Glide;

public class TVShowDetailActivity extends AppCompatActivity {
    public static final String EXTRA_TV_SHOW = "extra_movie";

    TextView tvName, tvVAvr, tvVCount, tvLanguage, tvOview;
    ImageView imagePhoto;

    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tvshow_detail);

        tvName = findViewById(R.id.tv_item_name);
        tvVAvr = findViewById(R.id.tv_item_voteAverege);
        tvVCount = findViewById(R.id.tv_item_voteCount);
        tvOview = findViewById(R.id.tv_item_overview);
        tvLanguage = findViewById(R.id.tv_item_language);
        imagePhoto = findViewById(R.id.img_item_photo);
        progressBar = findViewById(R.id.progressBarShowDetail);

        progressBar.setVisibility(View.VISIBLE);

        final Handler handler = new Handler();

        new Thread(new Runnable() {
            public void run() {
                try{
                    Thread.sleep(5000);
                }
                catch (Exception e) { }

                handler.post(new Runnable() {
                    public void run() {
                        TVShow tvShow = getIntent().getParcelableExtra(EXTRA_TV_SHOW);

                        String vote_average = Double.toString(tvShow.getVote_average());
                        String url_image = BuildConfig.IMAGE_DB_URL + tvShow.getPoster_path();

                        tvName.setText(tvShow.getName());
                        tvVAvr.setText(vote_average);
                        tvVCount.setText(tvShow.getVote_count());
                        tvOview.setText(tvShow.getOverview());
                        tvLanguage.setText(tvShow.getOriginal_language()) ;

                        Glide.with(TVShowDetailActivity.this)
                                .load(url_image)
                                .placeholder(R.color.colorAccent)
                                .dontAnimate()
                                .into(imagePhoto);

                        progressBar.setVisibility(View.INVISIBLE);
                    }
                });
            }
        }).start();
    }
}
